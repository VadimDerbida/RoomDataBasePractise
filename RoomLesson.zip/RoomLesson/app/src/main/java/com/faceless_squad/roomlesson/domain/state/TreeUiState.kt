package com.faceless_squad.roomlesson.domain.state

import com.faceless_squad.roomlesson.data.local.entity.TreeEntity

data class TreeUiState(
    val loading: Boolean,
    val trees: List<TreeEntity>,
    val treeById: TreeEntity? = null,
    val addTreeSuccess: Boolean,
    val events: List<Events>
) {

    sealed class Events {
        data class ShowError(val message: String): Events()
    }

    operator fun plus (event: Events) = this.copy(events = this.events + events)

    operator fun minus (event: Events) = this.copy(events = this.events - events)

}
