package com.faceless_squad.roomlesson.domain.usecase.tree

import com.faceless_squad.roomlesson.core.extensions.usecaseextension.UseCaseResult
import com.faceless_squad.roomlesson.data.datasource.contract.TreeInterface
import com.faceless_squad.roomlesson.data.local.entity.TreeEntity
import kotlinx.coroutines.flow.Flow

class DeleteTree(private val treeInterface: TreeInterface) {
    suspend operator fun invoke(treeEntity: TreeEntity) {
        return treeInterface.deleteTree(treeEntity)
    }
}