package com.faceless_squad.roomlesson.domain.usecase.tree

import com.faceless_squad.roomlesson.data.datasource.contract.TreeInterface
import com.faceless_squad.roomlesson.data.local.entity.TreeEntity

class InsertTree(private val treeInterface: TreeInterface) {
    suspend operator fun invoke(treeEntity: TreeEntity) {
        return treeInterface.insertTree(treeEntity)
    }
}