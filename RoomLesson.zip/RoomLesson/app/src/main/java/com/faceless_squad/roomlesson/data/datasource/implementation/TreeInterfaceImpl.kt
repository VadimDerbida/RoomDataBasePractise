package com.faceless_squad.roomlesson.data.datasource.implementation

import com.faceless_squad.roomlesson.core.extensions.usecaseextension.UseCaseResult
import com.faceless_squad.roomlesson.data.datasource.contract.TreeInterface
import com.faceless_squad.roomlesson.data.local.dao.TreeDao
import com.faceless_squad.roomlesson.data.local.entity.TreeEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class TreeInterfaceImpl @Inject constructor(
    private val treeDao: TreeDao
): TreeInterface {
    override fun getAllTrees(): Flow<List<TreeEntity>> {
        return treeDao.getAllTrees()
    }

    override suspend fun getTreeById(id: String): TreeEntity? {
        return treeDao.getTreeById(id)
    }

    override suspend fun insertTree(treeEntity: TreeEntity) {
        treeDao.insertTree(treeEntity)
    }

    override suspend fun deleteTree(treeEntity: TreeEntity) {
        treeDao.deleteTree(treeEntity)
    }
}