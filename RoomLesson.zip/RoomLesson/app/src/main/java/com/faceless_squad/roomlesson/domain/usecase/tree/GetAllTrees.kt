package com.faceless_squad.roomlesson.domain.usecase.tree

import com.faceless_squad.roomlesson.core.extensions.usecaseextension.UseCaseResult
import com.faceless_squad.roomlesson.data.datasource.contract.TreeInterface
import com.faceless_squad.roomlesson.data.local.entity.TreeEntity
import kotlinx.coroutines.flow.Flow


class GetAllTrees(private val treeInterface: TreeInterface) {
    operator fun invoke(): Flow<List<TreeEntity>> {
        return treeInterface.getAllTrees()
    }
}