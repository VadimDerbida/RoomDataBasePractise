package com.faceless_squad.roomlesson.core.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class RoomLessonApp: Application() {
}