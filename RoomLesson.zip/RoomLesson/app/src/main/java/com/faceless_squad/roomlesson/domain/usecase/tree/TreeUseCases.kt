package com.faceless_squad.roomlesson.domain.usecase.tree

data class TreeUseCases(
    val deleteTreeUseCase: DeleteTree,
    val insertTreeUseCase: InsertTree,
    val getAllTreesUseCase: GetAllTrees,
    val getTreeByIdUseCase: GetTreeById,
)
