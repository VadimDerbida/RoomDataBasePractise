package com.faceless_squad.roomlesson.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.faceless_squad.roomlesson.core.extensions.usecaseextension.onError
import com.faceless_squad.roomlesson.core.extensions.usecaseextension.onSuccess
import com.faceless_squad.roomlesson.data.local.entity.TreeEntity
import com.faceless_squad.roomlesson.domain.state.TreeUiState
import com.faceless_squad.roomlesson.domain.usecase.tree.TreeUseCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.lang.Exception
import java.util.*
import javax.inject.Inject

@HiltViewModel
class TreeViewModel @Inject constructor(
    val treeUseCases: TreeUseCases
) : ViewModel() {

    private val _uiState =
        MutableStateFlow(TreeUiState(loading = false, trees = listOf(), events = listOf(), addTreeSuccess = false))
    val uiState = _uiState.asStateFlow()

    init {
        loadAllTrees()
    }

    private fun loadAllTrees() {
        viewModelScope.launch {
            treeUseCases.getAllTreesUseCase()
                .onStart {
                    _uiState.update { value ->
                        value.copy(loading = true)
                    }
                }
                .collect { trees ->
                    _uiState.update { value ->
                        value.copy(loading = false, trees = trees)
                    }
                }
        }
    }

    fun loadTreeById(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val tree = treeUseCases.getTreeByIdUseCase(id = id)
            _uiState.update { state ->
                state.copy(treeById = tree)
            }
        }
    }

    fun addTree(name: String, price: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = UUID.randomUUID().toString()
            treeUseCases.insertTreeUseCase(
                treeEntity = TreeEntity(
                    id = id,
                    name = name,
                    price = price,
                    isBought = false
                )
            )

            try {
                val tree = treeUseCases.getTreeByIdUseCase(id = id)
                if (tree != null) {
                    _uiState.update { value ->
                        value.copy(loading = false, addTreeSuccess = true)
                    }
                } else {
                    _uiState.update { value ->
                        value.copy(loading = false)+ TreeUiState.Events.ShowError("Error while creating tree")
                    }
                }
            } catch (e: Exception) {
                _uiState.update { value ->
                    value.copy(loading = false)+ TreeUiState.Events.ShowError("Error while creating tree")
                }
            }
        }
    }

}