package com.faceless_squad.roomlesson.presentation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.faceless_squad.roomlesson.databinding.FragmentTreesBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest

@AndroidEntryPoint
class TreeFragment: Fragment() {

    private var _binding: FragmentTreesBinding? = null
    val binding get() = _binding!!
    val viewModel by viewModels<TreeViewModel>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTreesBinding.inflate(inflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observeFlow()

        binding.addFab.setOnClickListener {
            viewModel.addTree(name = "Cherry", price = 20)
        }
    }

    private fun observeFlow() {
        lifecycleScope.launchWhenCreated {
            viewModel.uiState.collectLatest { state ->
                when (state.loading) {
                    true -> binding.loadingBar.visibility = View.VISIBLE
                    false -> binding.loadingBar.visibility = View.GONE
                }

                when (state.trees.isNotEmpty()) {
                    true -> {
                        binding.treeCardView.visibility = View.VISIBLE
                        binding.treeNameText.text = state.trees.last().name
                        binding.treePriceText.text = "${state.trees.last().price} uah"
                        binding.isBoughtCheckbox.isChecked = state.trees.last().isBought
                    }
                    false -> {
                        binding.treeCardView.visibility = View.GONE
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}