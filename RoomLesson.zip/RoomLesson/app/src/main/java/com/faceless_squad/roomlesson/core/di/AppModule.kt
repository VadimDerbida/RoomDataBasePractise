package com.faceless_squad.roomlesson.core.di

import android.app.Application
import androidx.room.Room
import com.faceless_squad.roomlesson.data.datasource.contract.TreeInterface
import com.faceless_squad.roomlesson.data.datasource.implementation.TreeInterfaceImpl
import com.faceless_squad.roomlesson.data.local.RoomLessonDatabase
import com.faceless_squad.roomlesson.domain.usecase.tree.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    fun providesRoomDatabase(app: Application): RoomLessonDatabase {
        return Room.databaseBuilder(app, RoomLessonDatabase::class.java, "room_lesson_db").build()
    }

    @Provides
    fun providesTreeRepository(database: RoomLessonDatabase): TreeInterface {
        return TreeInterfaceImpl(treeDao = database.treeDao)
    }

    @Provides
    fun providesTreeUseCases(treeInterface: TreeInterface): TreeUseCases {
        return TreeUseCases(
            deleteTreeUseCase = DeleteTree(treeInterface = treeInterface),
            getTreeByIdUseCase = GetTreeById(treeInterface = treeInterface),
            insertTreeUseCase = InsertTree(treeInterface = treeInterface),
            getAllTreesUseCase = GetAllTrees(treeInterface = treeInterface)
        )
    }

}