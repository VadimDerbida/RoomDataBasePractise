package com.faceless_squad.roomlesson.data.local.converter

import androidx.room.TypeConverter
import com.faceless_squad.roomlesson.data.local.entity.TreeEntity
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken

object TreeConverter {

    @TypeConverter
    fun fromListGoalEntity(value: List<TreeEntity>?): String {
        val builder: GsonBuilder = GsonBuilder()
        val gson: Gson = builder.create()
        return gson.toJson(value)
    }

    @TypeConverter
    fun toListGoalEntity(value: String): List<TreeEntity> {
        val builder: GsonBuilder = GsonBuilder()
        val gson: Gson = builder.create()
        return gson.fromJson(value, Array<TreeEntity>::class.java).toList()
    }
}