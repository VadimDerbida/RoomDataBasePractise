package com.faceless_squad.roomlesson.data.local.entity

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Entity
@Parcelize
@Serializable
data class TreeEntity(
    @PrimaryKey(autoGenerate = false) val id: String = "",
    @ColumnInfo(name = "tree_name") val name: String = "",
    @ColumnInfo(name = "tree_price") val price: Int = 0,
    @ColumnInfo(name = "tree_bought") val isBought: Boolean = false
) : Parcelable
