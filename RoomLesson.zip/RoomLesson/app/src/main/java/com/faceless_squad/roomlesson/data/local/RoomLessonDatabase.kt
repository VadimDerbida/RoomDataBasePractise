package com.faceless_squad.roomlesson.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.faceless_squad.roomlesson.data.local.converter.TreeConverter
import com.faceless_squad.roomlesson.data.local.dao.TreeDao
import com.faceless_squad.roomlesson.data.local.entity.TreeEntity

@Database(
    entities = [TreeEntity::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(TreeConverter::class)
abstract class RoomLessonDatabase: RoomDatabase() {
    abstract val treeDao: TreeDao
}