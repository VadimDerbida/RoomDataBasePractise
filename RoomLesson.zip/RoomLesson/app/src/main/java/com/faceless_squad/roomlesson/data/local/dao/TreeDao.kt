package com.faceless_squad.roomlesson.data.local.dao

import androidx.room.*
import com.faceless_squad.roomlesson.core.extensions.usecaseextension.UseCaseResult
import com.faceless_squad.roomlesson.data.local.entity.TreeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TreeDao {

    // if we receiving list of something with Flow<> - then no suspend, else suspend

    @Query("SELECT * FROM treeentity")
    fun getAllTrees(): Flow<List<TreeEntity>>

    @Query("SELECT * FROM treeentity WHERE id = :id")
    suspend fun getTreeById(id: String): TreeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTree(treeEntity: TreeEntity)

    @Delete
    suspend fun deleteTree(treeEntity: TreeEntity)
}