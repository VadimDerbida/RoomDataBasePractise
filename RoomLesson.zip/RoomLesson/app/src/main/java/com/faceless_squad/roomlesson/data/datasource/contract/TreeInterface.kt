package com.faceless_squad.roomlesson.data.datasource.contract

import com.faceless_squad.roomlesson.core.extensions.usecaseextension.UseCaseResult
import com.faceless_squad.roomlesson.data.local.entity.TreeEntity
import kotlinx.coroutines.flow.Flow

interface TreeInterface {

    fun getAllTrees(): Flow<List<TreeEntity>>

    suspend fun getTreeById(id: String): TreeEntity?

    suspend fun insertTree(treeEntity: TreeEntity)

    suspend fun deleteTree(treeEntity: TreeEntity)
}